package wf.garnier.sso.resourceserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResourceserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
