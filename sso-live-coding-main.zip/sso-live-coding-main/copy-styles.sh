#!/usr/bin/env bash

cp style.css java/src/main/resources/static/style.css
cp style.css python/static/style.css
cp style.css javascript/static/style.css
cp style.css reference-implementations/java/src/main/resources/static/style.css
cp style.css reference-implementations/python/static/style.css
cp style.css reference-implementations/javascript/static/style.css
