rootProject.name = "sso.demo.reference"

pluginManagement {
    repositories {
        maven { url = uri("https://repo.spring.io/milestone/") }
        gradlePluginPortal()
    }
}
