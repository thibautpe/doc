rootProject.name = "sso.demo"

pluginManagement {
    repositories {
        maven { url = uri("https://repo.spring.io/milestone/") }
        gradlePluginPortal()
    }
}
