---
theme: default
class: "text-center"
highlighter: prism
lineNumbers: true
transition: none
# use UnoCSS
css: unocss
aspectRatio: "16/9"
colorSchema: "light"
canvasWidth: 1024
hideInToc: true
---

# OAuth2 & OpenID
## Sous le capot

<br>
<br>

### Daniel Garnier-Moiroux

Devoxx France, 2025-04-16


---
layout: image-right
image: /daniel-intro.jpg
hideInToc: true
class: smaller
---

#### Daniel
### Garnier-Moiroux
<br>

Software Engineer

- <logos-spring-icon /> Spring
- <logos-bluesky /> @garnier.wf
- <logos-firefox /> https://garnier.wf/
- <logos-github-icon /> github.com/Kehrlann/
- <fluent-emoji-flat-envelope-with-arrow /> contact@garnier.wf

---
hideInToc: true
---

# Le programme

<Toc maxDepth="2"></Toc>

---
layout: section
title: "OAuth2, OpenID: qu'est-ce que c'est?"
---

# OAuth2, OpenID
<br >

## C'est quoi, au juste?

---
title: OAuth2
level: 2
---

# OAuth 2 & 2.1

<br>

- Un framework d' *[🇬🇧 Authorization]*
  - Pour donner la **permission** à des **applications** d'accéder à des **ressources** via **HTTP**.
- Via des *jetons* appelés `access_token`
- Un ensemble de spécifications
  - **https://oauth.net/specs/** (parfois un peu ... rudes ...)


---
title: OAuth2 - Exemple
level: 3
---

# OAuth 2 & 2.1

Par exemple:

🧑🏻 **Daniel**

autorise

🖥️ **mon-album-photo.example.com**

à accéder à ses photos

📸 **Google Photos**

(sans partager son 🔐 mot de passe Google)

---
title: OAuth2
layout: fact
level: 3
---

## Notez: ça ne parle pas d'**identité** ...

---
title: OpenID Connect
level: 2
---

# OpenID Connect

<br>

- Un framework d' *[🇬🇧 Authentication]*
  - But: fournir à des **applications** tierces des données sur son identité détenues par un **provider
d'identité**.
  - Et donc faire du **Single-Sign-On** (SSO)
- Basé sur OAuth2, avec des jetons appelés `id_token`
- Et bien sûr... des specs!
  - **https://openid.net/developers/specs/**

---
layout: section
title: "Pourquoi et comment, en images"
level: 1
---

# Pourquoi et comment?

---
layout: image
image: /sso-1-give-password.png
hideInToc: true
---

---
layout: image
image: /sso-2-give-password-bad-idea.png
hideInToc: true
---

---
hideInToc: true
---

<img src="/sso-oauth-diagram.jpg" style="width: 800px; text-align:center;" />

---
hideInToc: true
---

<img src="/sso-oauth-diagram-waldo.jpg" style="width: 800px; text-align:center;" />

---
layout: image
image: /sso-3-high-level-authorization-code.png
hideInToc: true
---

---
layout: image
image: /sso-4-high-level-token-types.png
hideInToc: true
---

---
layout: image
image: /sso-3-high-level-authorization-code.png
hideInToc: true
---

---
layout: image
image: /sso-5-more-details-oauth.png
hideInToc: true
---

---
layout: image
image: /sso-6-just-sso.png
hideInToc: true
---

---
layout: center
title: Live-coding
---

# ~~~ Du code!

<img src="/cat-code.gif" style="width: 600px; text-align:center;" />

---
layout: image-right
image: /no-idea.jpg
hideInToc: true
---

## 🚨**WARNING**🚨

<br>Ce live-coding est réalisé par un professionel<sup>1</sup>. N'essayez surtout pas de le
reproduire en prod.

<br><sup>1</sup> ou pas 🥸

---
layout: image
image: /sso-7-get-code.png
hideInToc: true
---

---
layout: image
image: /sso-8-code-where.png
hideInToc: true
---

---
layout: image
image: /sso-9-authorization-uri.png
hideInToc: true
---

---
layout: image
image: /sso-10-redirect.png
hideInToc: true
---

---
layout: image
image: /sso-11-exchange-token.png
hideInToc: true
---

---
layout: image
image: /sso-12-jwt.png
hideInToc: true
---

---
layout: image-right
image: /safety-cat.jpg
hideInToc: true
---

## Rappel!

<br>Ne faites pas ça! Utilisez une lib.

---
layout: two-cols
hideInToc: true
---

### **OAUTH 2.1 expliqué simplement**
### **(même si tu n'es pas dev) !**

Julien Topçu, Devoxx 2023

<img src="/qr-code-talk-julien.png" style="height: 200px; margin-left: 50px;">

::right::

<img src="/julien-topcu-oauth2.png">


---
layout: default
hideInToc: true
---

# References

<br>

### **https://github.com/Kehrlann/sso-live-coding**

<!-- ouch the hack -->
<!-- https://mobile.devoxx.com/events/devoxxfr2025/rate-talk/50283 -->
<div style="float:right; margin-right: 50px; text-align: center;">
  <img src="/qr-code.png" style="margin-bottom: -45px; margin-top: -15px;" >
</div>

<br>

- <logos-bluesky /> @garnier.wf
- <logos-firefox /> https://garnier.wf/
- <fluent-emoji-flat-envelope-with-arrow /> contact@garnier.wf

---
layout: default
class: smaller
hideInToc: true
---

# Spring team talks

&nbsp;

- **Null Safety en Java avec JSpecify et NullAway** (Tools-in-Action)
    - Sébastien Deleuze, Mercredi, 17:50, Neuilly 252AB
- **Optimisez vos applications Spring Boot avec CDS et Project Leyden**
    - Sébastien Deleuze, Jeudi, 14:35, Amphi Bleu
- **BOF Spring**
    - Sébastien & Daniel, Jeudi, 20:00, Paris 241
- **Tester les apps Spring Boot, sous toutes les coutures** (Deep Dive)
    - Daniel, Vendredi, 13:30, Paris 141

---
layout: image
hideInToc: true
image: /meet-me.jpg
class: end
---

# **Merci 😊**

